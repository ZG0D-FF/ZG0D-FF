/* ═══════════════════════════════════════════
   StudyOS — script.js
   ▸ Paste your notes inside the `notes` array.
   ▸ Each object follows the same schema.
   ▸ formulas support LaTeX: use \\( ... \\) inline,  \\[ ... \\] display.
═══════════════════════════════════════════ */

const notes = [
  {
    title: "Fourier Transform",
    summary: "Converts a signal from the time domain into the frequency domain, revealing its constituent frequencies.",
    points: [
      "Linear operation: F{af+bg} = aF{f} + bF{g}",
      "Invertible — original signal fully recoverable",
      "Core tool in signal processing, communications, and image analysis",
      "Discrete version (DFT) is computed via FFT in O(N log N)"
    ],
    formulas: [
      "\\( X(f) = \\int_{-\\infty}^{\\infty} x(t)\\,e^{-j2\\pi ft}\\,dt \\)",
      "\\( x(t) = \\int_{-\\infty}^{\\infty} X(f)\\,e^{j2\\pi ft}\\,df \\)"
    ],
    facts: [
      "FT of a sinc function is a rectangular function (duality)",
      "Convolution in time ↔ multiplication in frequency",
      "Parseval's theorem: energy is preserved across domains"
    ],
    examples: [
      "sinc(t)  ↔  rect(f)",
      "Gaussian ↔ Gaussian (self-dual)",
      "Impulse δ(t) ↔ 1 (flat spectrum)"
    ]
  },
  {
    title: "Backpropagation",
    summary: "Algorithm to compute gradients of the loss w.r.t. all weights by applying the chain rule layer-by-layer in reverse.",
    points: [
      "Forward pass: compute outputs and cache activations",
      "Backward pass: propagate δ (error signals) from output to input",
      "Each weight update: w ← w − η · ∂L/∂w",
      "Requires differentiable activation functions"
    ],
    formulas: [
      "\\( \\delta^{(l)} = (W^{(l+1)})^T \\delta^{(l+1)} \\odot \\sigma'(z^{(l)}) \\)",
      "\\( \\frac{\\partial L}{\\partial W^{(l)}} = \\delta^{(l)} (a^{(l-1)})^T \\)"
    ],
    facts: [
      "Vanishing gradient problem worsens with depth and sigmoid activations",
      "ReLU mitigates vanishing gradients (gradient = 1 for positive inputs)",
      "Batch normalisation helps stabilise gradient magnitudes"
    ],
    examples: [
      "2-layer MLP: gradients flow output → hidden → input",
      "LSTM gates use truncated BPTT to limit gradient flow over time"
    ]
  },
  {
    title: "Convolutional Neural Networks (CNNs)",
    summary: "Exploit spatial locality via learnable filter banks; weight sharing drastically reduces parameters.",
    points: [
      "Convolution layer: applies K filters of size F×F",
      "Pooling: spatial downsampling (max or average)",
      "Receptive field grows with depth",
      "Translation equivariance built in"
    ],
    formulas: [
      "\\( (I * K)[i,j] = \\sum_m \\sum_n I[i+m,\\, j+n]\\, K[m,n] \\)",
      "Output size: \\( \\left\\lfloor \\frac{W - F + 2P}{S} \\right\\rfloor + 1 \\)"
    ],
    facts: [
      "AlexNet (2012) started the deep learning revolution on ImageNet",
      "Depthwise separable convolutions (MobileNet) cut compute by ~8-9×",
      "Batch norm + skip connections (ResNet) allow 100+ layer training"
    ],
    examples: [
      "LeNet-5 for digit recognition (1998)",
      "ResNet-50: 50 layers with residual shortcuts",
      "YOLO: single-pass CNN for real-time object detection"
    ]
  },
  {
    title: "Attention & Transformers",
    summary: "Self-attention computes pairwise token relationships; Transformers stack these to achieve global context in O(N²) time.",
    points: [
      "Query, Key, Value projections from the same input",
      "Attention weights via softmax-scaled dot product",
      "Multi-head: run H attention functions in parallel, concat",
      "Positional encoding adds sequence order information"
    ],
    formulas: [
      "\\( \\text{Attention}(Q,K,V) = \\text{softmax}\\!\\left(\\frac{QK^T}{\\sqrt{d_k}}\\right)V \\)",
      "\\( \\text{PE}_{(pos,2i)} = \\sin\\!\\left(\\frac{pos}{10000^{2i/d}}\\right) \\)"
    ],
    facts: [
      "BERT uses encoder-only; GPT uses decoder-only",
      "Quadratic memory in sequence length is the main bottleneck",
      "Flash Attention reorders computation for IO efficiency"
    ],
    examples: [
      "GPT-4: decoder-only transformer, 1.8T parameters (estimated)",
      "Vision Transformer (ViT): images split into 16×16 patches as tokens"
    ]
  },
  {
    title: "Gradient Descent Variants",
    summary: "Optimisation algorithms for minimising loss by iterative parameter updates using gradient information.",
    points: [
      "SGD: update per mini-batch, noisy but fast",
      "Momentum: accumulate velocity to escape flat regions",
      "Adam: adaptive per-parameter learning rates with bias correction",
      "Learning rate warmup + cosine decay is the de facto schedule"
    ],
    formulas: [
      "SGD: \\( \\theta \\leftarrow \\theta - \\eta \\nabla_\\theta L \\)",
      "Adam: \\( \\hat{m}_t = m_t/(1-\\beta_1^t),\\quad \\hat{v}_t = v_t/(1-\\beta_2^t) \\)",
      "\\( \\theta \\leftarrow \\theta - \\frac{\\eta}{\\sqrt{\\hat{v}_t}+\\epsilon}\\hat{m}_t \\)"
    ],
    facts: [
      "Adam default: β₁=0.9, β₂=0.999, ε=1e-8",
      "AdamW decouples weight decay from gradient update",
      "Gradient clipping (norm ≤ 1.0) prevents exploding gradients in RNNs"
    ],
    examples: [
      "LLM pre-training: AdamW + cosine LR with linear warmup",
      "Image classification: SGD + momentum + step LR decay"
    ]
  }
  /* ─── ADD MORE TOPICS HERE ───────────────────────────────────────────
  ,{
    title: "Your Topic Title",
    summary: "One or two sentence overview.",
    points: [
      "Key point 1",
      "Key point 2"
    ],
    formulas: [
      "\\( your = LaTeX \\)",
      "Plain text formula also fine"
    ],
    facts: [
      "Important fact 1",
      "Important fact 2"
    ],
    examples: [
      "Example A",
      "Example B"
    ]
  }
  ───────────────────────────────────────────────────────────────────── */
];

/* ═══════════════════════════════════════════
   DOM references
═══════════════════════════════════════════ */
const cardsGrid   = document.getElementById('cardsGrid');
const navList     = document.getElementById('navList');
const searchInput = document.getElementById('searchInput');
const progressBar = document.getElementById('progressBar');
const noResults   = document.getElementById('noResults');
const focusBtn    = document.getElementById('focusBtn');
const themeBtn    = document.getElementById('themeBtn');
const sectionCount= document.getElementById('sectionCount');
const parallax    = document.getElementById('parallax');

let currentIndex = 0;   // for N / B navigation
let visibleCards = [];  // after filtering

/* ═══════════════════════════════════════════
   Build cards
═══════════════════════════════════════════ */
function buildCard(note, idx) {
  const id = `card-${idx}`;

  // ── nav item
  const li = document.createElement('li');
  li.className = 'nav-item';
  li.dataset.idx = idx;
  const a = document.createElement('a');
  a.href = `#${id}`;
  a.textContent = note.title;
  a.addEventListener('click', () => highlightNav(idx));
  li.appendChild(a);
  navList.appendChild(li);

  // ── card
  const card = document.createElement('div');
  card.className = 'card open'; // open by default
  card.id = id;
  card.dataset.idx = idx;

  // header
  const header = document.createElement('div');
  header.className = 'card-header';
  header.innerHTML = `
    <span class="card-title">${note.title}</span>
    <span class="card-toggle">›</span>`;
  header.addEventListener('click', () => {
    card.classList.toggle('open');
  });

  // body
  const body = document.createElement('div');
  body.className = 'card-body';
  body.innerHTML = `
    <p class="section-label">Summary</p>
    <p class="summary-text">${note.summary}</p>

    ${note.points?.length ? `
    <p class="section-label">Key Points</p>
    <ul class="points-list">
      ${note.points.map(p => `<li>${p}</li>`).join('')}
    </ul>` : ''}

    ${note.formulas?.length ? `
    <p class="section-label">Formulas</p>
    <div class="formulas-block">
      ${note.formulas.map(f => `<div class="formula-item">${f}</div>`).join('')}
    </div>` : ''}

    ${note.facts?.length ? `
    <p class="section-label">Important Facts</p>
    <div class="facts-block">
      ${note.facts.map(f => `<div class="fact-item">${f}</div>`).join('')}
    </div>` : ''}

    ${note.examples?.length ? `
    <p class="section-label">Examples</p>
    <ul class="examples-list">
      ${note.examples.map(e => `<li>${e}</li>`).join('')}
    </ul>` : ''}
  `;

  card.appendChild(header);
  card.appendChild(body);
  cardsGrid.appendChild(card);
}

function init() {
  notes.forEach((note, idx) => buildCard(note, idx));
  sectionCount.textContent = `${notes.length} topics`;
  visibleCards = [...document.querySelectorAll('.card')];

  // Typeset MathJax after cards exist
  if (window.MathJax?.typesetPromise) {
    MathJax.typesetPromise([cardsGrid]).catch(console.warn);
  }
}

/* ═══════════════════════════════════════════
   Search
═══════════════════════════════════════════ */
function doSearch(query) {
  const q = query.trim().toLowerCase();
  visibleCards = [];
  let matched = 0;

  notes.forEach((note, idx) => {
    const card    = document.getElementById(`card-${idx}`);
    const navItem = navList.querySelector(`[data-idx="${idx}"]`);
    const haystack = [
      note.title, note.summary,
      ...(note.points  || []),
      ...(note.formulas|| []),
      ...(note.facts   || []),
      ...(note.examples|| [])
    ].join(' ').toLowerCase();

    const show = !q || haystack.includes(q);
    card.classList.toggle('hidden', !show);
    navItem.classList.toggle('hidden', !show);

    if (show) { visibleCards.push(card); matched++; }
  });

  noResults.classList.toggle('hidden', matched > 0);
  sectionCount.textContent = q ? `${matched}/${notes.length} topics` : `${notes.length} topics`;
  currentIndex = 0;
}

searchInput.addEventListener('input', e => doSearch(e.target.value));

/* ═══════════════════════════════════════════
   Progress bar
═══════════════════════════════════════════ */
window.addEventListener('scroll', () => {
  const total = document.body.scrollHeight - window.innerHeight;
  const pct   = total > 0 ? (window.scrollY / total) * 100 : 0;
  progressBar.style.width = pct + '%';

  // highlight active nav item based on scroll
  visibleCards.forEach((card, i) => {
    const rect = card.getBoundingClientRect();
    if (rect.top <= 80 && rect.bottom > 80) {
      highlightNav(+card.dataset.idx);
    }
  });
});

function highlightNav(idx) {
  navList.querySelectorAll('a').forEach(a => a.classList.remove('active'));
  const a = navList.querySelector(`[data-idx="${idx}"] a`);
  if (a) a.classList.add('active');
  currentIndex = visibleCards.findIndex(c => +c.dataset.idx === idx);
}

/* ═══════════════════════════════════════════
   Keyboard shortcuts
═══════════════════════════════════════════ */
document.addEventListener('keydown', e => {
  const tag = document.activeElement.tagName;
  const inInput = tag === 'INPUT' || tag === 'TEXTAREA';

  if (e.key === '/' && !inInput) {
    e.preventDefault();
    searchInput.focus();
    searchInput.select();
    return;
  }

  if (e.key === 'Escape' && inInput) {
    searchInput.blur();
    return;
  }

  if (inInput) return;

  if (e.key === 'n' || e.key === 'N') {
    e.preventDefault();
    navigateSection(1);
  }
  if (e.key === 'b' || e.key === 'B') {
    e.preventDefault();
    navigateSection(-1);
  }
  if (e.key === 'f' || e.key === 'F') {
    e.preventDefault();
    toggleFocus();
  }
});

function navigateSection(dir) {
  if (!visibleCards.length) return;
  currentIndex = (currentIndex + dir + visibleCards.length) % visibleCards.length;
  visibleCards[currentIndex].scrollIntoView({ behavior: 'smooth', block: 'start' });
  highlightNav(+visibleCards[currentIndex].dataset.idx);
}

/* ═══════════════════════════════════════════
   Focus mode
═══════════════════════════════════════════ */
function toggleFocus() {
  document.body.classList.toggle('focus');
  focusBtn.textContent = document.body.classList.contains('focus') ? '◈ Exit' : '◈ Focus';
}
focusBtn.addEventListener('click', toggleFocus);

/* ═══════════════════════════════════════════
   Light / dark toggle
═══════════════════════════════════════════ */
themeBtn.addEventListener('click', () => {
  document.body.classList.toggle('light');
});

/* ═══════════════════════════════════════════
   Parallax
═══════════════════════════════════════════ */
window.addEventListener('scroll', () => {
  parallax.style.transform = `translateY(${window.scrollY * 0.25}px)`;
}, { passive: true });

/* ═══════════════════════════════════════════
   Mobile sidebar toggle (topbar pseudo-element click)
═══════════════════════════════════════════ */
document.querySelector('.topbar').addEventListener('click', e => {
  if (window.innerWidth <= 768) {
    const rect = e.currentTarget.getBoundingClientRect();
    if (e.clientX - rect.left < 38) {          // tap on hamburger zone
      document.body.classList.toggle('sidebar-open');
    }
  }
});

// close sidebar on nav link tap (mobile)
navList.addEventListener('click', () => {
  if (window.innerWidth <= 768) {
    document.body.classList.remove('sidebar-open');
  }
});

/* ─── RUN ─── */
init();
